/**
 * CKS Paket — sürüm bilgisi ve uzaktan güncelleme kontrolü
 */
const path = require('path');
const fs = require('fs');
const axios = require('axios');

function mevcutSurumAl(kok) {
  const pkgPath = path.join(kok, 'package.json');
  const pkg = JSON.parse(fs.readFileSync(pkgPath, 'utf8'));
  return {
    surum: pkg.version || '0.0.0',
    ad: pkg.name || 'ckspaket',
    aciklama: pkg.description || ''
  };
}

/** a > b → pozitif, eşit → 0 */
function surumKarsilastir(a, b) {
  const pa = String(a).split('.').map((n) => parseInt(n, 10) || 0);
  const pb = String(b).split('.').map((n) => parseInt(n, 10) || 0);
  const uzun = Math.max(pa.length, pb.length);
  for (let i = 0; i < uzun; i++) {
    const diff = (pa[i] || 0) - (pb[i] || 0);
    if (diff !== 0) return diff;
  }
  return 0;
}

async function uzakManifestAl(url) {
  const res = await axios.get(url, {
    timeout: 15000,
    validateStatus: (s) => s === 200,
    headers: { Accept: 'application/json' }
  });
  return res.data;
}

function registerPaketGuncelleme(app, opts) {
  const { gercekKlasor, CKSPAKET_MOD } = opts;
  if (!CKSPAKET_MOD) return;

  const guncellemeKlasor = path.join(gercekKlasor, 'guncellemeler');
  if (!fs.existsSync(guncellemeKlasor)) {
    fs.mkdirSync(guncellemeKlasor, { recursive: true });
  }
  app.use('/guncellemeler', require('express').static(guncellemeKlasor));

  app.get('/api/paket-surum', (_req, res) => {
    try {
      res.json({ success: true, ...mevcutSurumAl(gercekKlasor) });
    } catch (err) {
      res.status(500).json({ success: false, message: err.message });
    }
  });

  app.get('/api/paket-guncelle-kontrol', async (_req, res) => {
    try {
      const mevcut = mevcutSurumAl(gercekKlasor);
      const manifestUrl = String(process.env.GUNCELLEME_URL || '').trim();
      if (!manifestUrl) {
        return res.json({
          success: true,
          guncellemeVar: false,
          mevcutSurum: mevcut.surum,
          mesaj: 'GUNCELLEME_URL tanımlı değil (.env)'
        });
      }
      const manifest = await uzakManifestAl(manifestUrl);
      const yeniSurum = String(manifest.surum || manifest.version || '').trim();
      const guncellemeVar = Boolean(yeniSurum && surumKarsilastir(yeniSurum, mevcut.surum) > 0);
      res.json({
        success: true,
        guncellemeVar,
        mevcutSurum: mevcut.surum,
        yeniSurum,
        tarih: manifest.tarih || manifest.releaseDate || '',
        notlar: manifest.notlar || manifest.notes || manifest.changelog || '',
        indirmeUrl: manifest.indirmeUrl || manifest.downloadUrl || ''
      });
    } catch (err) {
      res.json({
        success: false,
        guncellemeVar: false,
        message: err.message || 'Güncelleme sunucusuna ulaşılamadı'
      });
    }
  });
}

module.exports = {
  mevcutSurumAl,
  surumKarsilastir,
  registerPaketGuncelleme
};
