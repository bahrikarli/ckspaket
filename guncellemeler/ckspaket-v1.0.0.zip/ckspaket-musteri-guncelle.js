/**
 * Müşteri kurulumunda güncelleme uygular.
 * Sunucu kapalıyken çalıştırın: ckspaket-musteri-guncelle.bat
 */
const fs = require('fs');
const path = require('path');
const { execSync } = require('child_process');
const axios = require('axios');
const { surumKarsilastir, mevcutSurumAl } = require('./paket-guncelleme');

const KOK = __dirname;

try {
  require('dotenv').config({ path: path.join(KOK, '.env'), quiet: true });
} catch (_) {}

const KORU_DOSYALAR = ['.env'];
const KORU_KLASORLER = ['taramalar', 'uploads', 'guncellemeler'];

async function manifestAl() {
  const url = String(process.env.GUNCELLEME_URL || '').trim();
  if (!url) throw new Error('GUNCELLEME_URL .env dosyasinda tanimli degil');
  const res = await axios.get(url, { timeout: 30000, validateStatus: (s) => s === 200 });
  return res.data;
}

async function zipIndir(url, hedef) {
  const res = await axios.get(url, {
    responseType: 'arraybuffer',
    timeout: 120000,
    validateStatus: (s) => s === 200
  });
  fs.mkdirSync(path.dirname(hedef), { recursive: true });
  fs.writeFileSync(hedef, Buffer.from(res.data));
}

function yedekAl() {
  const yedekKok = path.join(KOK, '_guncelleme_yedek');
  if (fs.existsSync(yedekKok)) fs.rmSync(yedekKok, { recursive: true, force: true });
  fs.mkdirSync(yedekKok, { recursive: true });

  for (const ad of KORU_DOSYALAR) {
    const src = path.join(KOK, ad);
    if (fs.existsSync(src)) fs.copyFileSync(src, path.join(yedekKok, ad));
  }
  for (const ad of KORU_KLASORLER) {
    const src = path.join(KOK, ad);
    if (fs.existsSync(src)) {
      execSync(`xcopy "${src}" "${path.join(yedekKok, ad)}\\" /E /I /Y /Q`, { stdio: 'inherit' });
    }
  }
  return yedekKok;
}

function zipAc(zipYol, hedefKlasor) {
  fs.mkdirSync(hedefKlasor, { recursive: true });
  const ps = [
    `$zip = '${zipYol.replace(/'/g, "''")}'`,
    `$dst = '${hedefKlasor.replace(/'/g, "''")}'`,
    'Expand-Archive -Path $zip -DestinationPath $dst -Force'
  ].join('; ');
  execSync(`powershell -NoProfile -Command "${ps}"`, { stdio: 'inherit' });
}

function dosyalariUygula(kaynak, hedef) {
  for (const ad of fs.readdirSync(kaynak)) {
    const src = path.join(kaynak, ad);
    const dst = path.join(hedef, ad);
    if (KORU_DOSYALAR.includes(ad)) continue;
    if (KORU_KLASORLER.includes(ad)) continue;
    const st = fs.statSync(src);
    if (st.isDirectory()) {
      if (fs.existsSync(dst)) fs.rmSync(dst, { recursive: true, force: true });
      execSync(`xcopy "${src}" "${dst}\\" /E /I /Y /Q`, { stdio: 'inherit' });
    } else {
      fs.copyFileSync(src, dst);
    }
  }
}

function yedekGeri(yedekKok) {
  for (const ad of KORU_DOSYALAR) {
    const src = path.join(yedekKok, ad);
    if (fs.existsSync(src)) fs.copyFileSync(src, path.join(KOK, ad));
  }
  for (const ad of KORU_KLASORLER) {
    const src = path.join(yedekKok, ad);
    if (fs.existsSync(src)) {
      const dst = path.join(KOK, ad);
      if (!fs.existsSync(dst)) fs.mkdirSync(dst, { recursive: true });
      execSync(`xcopy "${src}" "${dst}\\" /E /I /Y /Q`, { stdio: 'inherit' });
    }
  }
}

(async () => {
  console.log('=== CKS Paket — Musteri Guncelleme ===');
  console.log('Klasor:', KOK);
  console.log('');

  const mevcut = mevcutSurumAl(KOK);
  console.log('Mevcut surum:', mevcut.surum);

  const manifest = await manifestAl();
  const yeniSurum = String(manifest.surum || manifest.version || '').trim();
  const indirmeUrl = String(manifest.indirmeUrl || manifest.downloadUrl || '').trim();

  if (!yeniSurum || !indirmeUrl) {
    throw new Error('Manifest eksik: surum veya indirmeUrl yok');
  }

  if (surumKarsilastir(yeniSurum, mevcut.surum) <= 0) {
    console.log('');
    console.log('Zaten guncel. Yeni surum yok.');
    process.exit(0);
  }

  console.log('Yeni surum:', yeniSurum);
  if (manifest.notlar) console.log('Notlar:', manifest.notlar);
  console.log('');

  const tmpZip = path.join(KOK, 'guncellemeler', '_indirilen.zip');
  const tmpAc = path.join(KOK, 'guncellemeler', '_acilan');

  console.log('Indiriliyor...');
  await zipIndir(indirmeUrl, tmpZip);

  console.log('Yedek aliniyor (.env, taramalar)...');
  const yedek = yedekAl();

  try {
    if (fs.existsSync(tmpAc)) fs.rmSync(tmpAc, { recursive: true, force: true });
    console.log('ZIP aciliyor...');
    zipAc(tmpZip, tmpAc);
    console.log('Dosyalar uygulaniyor...');
    dosyalariUygula(tmpAc, KOK);
    yedekGeri(yedek);
  } catch (err) {
    console.error('HATA:', err.message);
    console.log('Yedek geri yukleniyor...');
    yedekGeri(yedek);
    process.exit(1);
  } finally {
    if (fs.existsSync(tmpAc)) fs.rmSync(tmpAc, { recursive: true, force: true });
    if (fs.existsSync(tmpZip)) fs.unlinkSync(tmpZip);
    if (fs.existsSync(yedek)) fs.rmSync(yedek, { recursive: true, force: true });
  }

  console.log('');
  console.log('npm install calistiriliyor...');
  execSync('npm install --omit=dev', { cwd: KOK, stdio: 'inherit' });

  const guncel = mevcutSurumAl(KOK);
  console.log('');
  console.log('Guncelleme tamamlandi. Surum:', guncel.surum);
  console.log('Sunucuyu baslatmak icin: ckspaket-baslat.bat');
})().catch((err) => {
  console.error('');
  console.error('GUNCELLEME BASARISIZ:', err.message);
  process.exit(1);
});
