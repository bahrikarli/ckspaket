# CKS Paket

Sade ofis sistemi — ana `c:\cks` projesinin hafif sürümü.

## Modüller

| Kart | Açıklama |
|------|----------|
| Personel Paneli | Kullanıcı yönetimi (admin) |
| Çiftçi Kayıt | `cks.html` + `dilekce.html`, formlar, eksikler vb. |
| Arşiv | Odalar + ÇKS Dosyaları (hangi klasör hangi odada) |
| Profilim | Ad, soyad, e-posta, şifre |
| Mesajlar | Personel arası mesajlaşma |

**Dahil değil:** Market, sıramatik, mesai, belgenet robot, demirbaş, yazışmalar vb.

## Kurulum

1. `config.js` — SQL bağlantısını kontrol edin (ana CKS ile aynı veritabanı).
2. `.env` içinde **`PORT=3030`** olmalı (ana CKS'ten kopyaladıysanız 3000 kalmış olabilir).
3. `npm install`
4. `ckspaket-baslat.bat` veya `node server.js` — sunucu **port 3030**'da açılır.

## Adresler

- Yerel: http://127.0.0.1:3030
- Ağ: http://192.168.1.123:3030 (IP'yi `ckspaket-ayar.bat` içinde düzenleyin)

## Ana CKS'ten güncelleme (senkron)

`c:\cks` içinde değişiklik yaptıysanız:

| Ne | Komut (`c:\cks` içinde) |
|----|-------------------------|
| **İkisi birlikte** (belgenet + çiftçi paket) | `cks-guncelle.bat` |
| Sadece ckspaket (çiftçi kayıt) | `ckspaket-sync.bat` |
| Sadece yenıservercks (belgenet) | `yenıservercks-guncelle.bat` |

**Kopyalanır:** `server.js`, `cks.html`, `dilekce.html`, formlar, eksikler vb.  
**Korunur:** `anasayfa.html`, `arsiv.html`, `sistem-ayar.js`, `.env`, `taramalar/` içeriği  
**Otomatik yama:** port 3030, `C:\ckspaket\taramalar`, göreli PDF/API yolları

Senkron sonrası ckspaket sunucusunu yeniden başlatın.

## Oda resimleri

`public\img\odalar\1.jpg`, `2.jpg` … şeklinde kaydedin.

## ÇKS dosyaları

`VTÇKS` tablosu — her kayıt bir **klasör numarası (Alan1)** ve **oda** bilgisi tutar.  
Çiftçi kayıt ekranındaki Arşiv Analiz Paneli de aynı yıl klasör yollarını gösterir.

## Taramalar klasörü (boş şablon)

Paketle birlikte boş klasör yapısı gelir — PDF kopyalanmaz:

```
c:\ckspaket\taramalar\
  ckstaramalar\   ← tarama havuzu (personel adıyla başlayan PDF'ler)
  2026cks\        ← onaylanan yıllık arşiv
  2027cks\
  ib\             ← IB form arşivi
  ibtaramalar\    ← IB tarama havuzu
```

Varsayılan kök yol: `C:\ckspaket\taramalar` (`sistem-ayar.js` ve Çiftçi Kayıt → Tanımlamalar).  
Yeni yıl için `2028cks` gibi alt klasörü elle ekleyebilirsiniz.

### Ağ paylaşımı (tarayıcı UNC yolu)

`C:\ckspaket\taramalar` için ağ yolları **`\\SUNUCU-IP\ckspaket\taramalar\...`** şeklinde üretilir.

Sunucuda bir kez yapın:
1. `C:\ckspaket` klasörüne sağ tık → **Paylaş** → paylaşım adı: **`ckspaket`**
2. Tarayıcı kayıt yolu (tüm PC’lerde): `\\192.168.1.120\ckspaket\taramalar\ckstaramalar`

Eski ana CKS (`C:\cks\taramalar`) hâlâ `\\sunucu\cks\taramalar` olarak kalır.

## Müşteri paketi oluşturma (TEK BAT)

Yeni sürüm yayınlamak için **sadece** şunu çalıştırın:

```
ckspaket-yayinla.bat
```

Otomatik yapılanlar:
1. Ana CKS senkronu (`c:\cks` varsa)
2. Sürüm numarası artırma (`1.0.0` → `1.0.1`)
3. Müşteri ZIP oluşturma (`dist\ckspaket-v1.0.1.zip`)
4. `guncellemeler\guncelleme.json` — IP/port otomatik (`ckspaket-ayar.bat`)
5. `.env` içine `GUNCELLEME_URL` yazılır

IP adresini `ckspaket-ayar.bat` içindeki `CKS_SUNUCU_IP` satırından alır.

### İlk müşteri kurulumu

1. `dist\ckspaket-v1.0.0.zip` dosyasını `C:\ckspaket` klasörüne açın
2. `.env.example` → `.env` kopyalayın, SQL bilgilerini girin
3. `npm install`
4. `ckspaket-baslat.bat`

## Otomatik güncelleme (müşteri — TEK BAT)

Müşteri bilgisayarında **sadece** şunu çalıştırın:

```
ckspaket-musteri-guncelle.bat
```

Otomatik yapılanlar:
1. Sunucuyu durdurur (port 3030)
2. Yeni sürümü indirir ve kurar (`.env` ve `taramalar/` korunur)
3. `npm install`
4. Sunucuyu yeniden başlatır

### Program içinden (admin)

Ana sayfada **“Yeni sürüm mevcut”** bildirimi çıkar. Admin **“Şimdi Güncelle”** butonuna basarsa aynı işlem otomatik başlar.

### Müşteri `.env` ayarı

Yayın bat'ı sizin sunucunuzda `.env`'i otomatik ayarlar. Müşterinin `.env` dosyasında şu satır olmalı (sizin sunucu IP'niz):

```
GUNCELLEME_URL=http://192.168.1.123:3030/guncellemeler/guncelleme.json
```

(`ckspaket-ayar.bat` içindeki IP ile aynı olmalı)
