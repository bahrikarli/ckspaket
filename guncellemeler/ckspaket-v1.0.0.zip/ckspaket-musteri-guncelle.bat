@echo off
title CKS Paket — Guncelleme
cd /d "%~dp0"

echo.
echo === CKS PAKET GUNCELLEME ===
echo ONEMLI: Once ckspaket-baslat.bat penceresini kapatin (sunucu durmali).
echo.

set /p ONAY=Guncellemeye devam? (E/H): 
if /i not "%ONAY%"=="E" exit /b 0

echo.
echo Port 3030 kontrol ediliyor...
for /f "tokens=5" %%a in ('netstat -ano 2^>nul ^| findstr ":3030" ^| findstr LISTENING') do (
  echo HATA: Port 3030 hala acik (PID %%a). Sunucuyu kapatip tekrar deneyin.
  pause
  exit /b 1
)

node ckspaket-musteri-guncelle.js
if errorlevel 1 (
  echo.
  echo Guncelleme basarisiz.
  pause
  exit /b 1
)

echo.
echo Basariyla guncellendi. Sunucuyu baslatabilirsiniz.
pause
